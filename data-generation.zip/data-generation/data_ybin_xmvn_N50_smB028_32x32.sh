#!/bin/bash
#SBATCH --share
#SBATCH --partition=express
#SBATCH --job-name=data_ybin_xmvn_N50_smB028_32x32
#SBATCH --error=data_ybin_xmvn_N50_smB028_32x32.err
#SBATCH --output=data_ybin_xmvn_N50_smB028_32x32.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=jleach@uab.edu
#SBATCH --time=1:59:00
#SBATCH --mem-per-cpu=50GB

module load R/3.6.0-foss-2018a-X11-20180131-bare
srun R CMD BATCH /data/user/jleach/sim_01_2020/Rcode/data_ybin_xmvn_N50_smB028_32x32.R
