# Binary outcomes; MVN images
# betas <- 0.1
# 32 x 32 images
# non-zero parameters: 29 (~2.8%)
# N = 100

# load packages
library(tidyverse)
library(sim2Dpredictr)

set.seed(87462384)

# How many simulations?
M <- 10000

# How many subjects per dataset?
N <- 100

# Continuous or binary predictors?
x.ms <- "continuous"
# x.ms <- "binary"

# Continuous or binary outcomes?
y.ms <- "binomial"
# y.ms <- "gaussian"

# image resolution; i.e., number of predictors
im.res <- c(32, 32)

if (x.ms == "continuous") {
  # can modify these arguments if needed.
  L = chol_s2Dp(im.res = im.res, rho = 0.90,
                corr.structure = "ar1",
                triangle = "lower")
}

# generate parameter vector
betas <- beta_builder(index.type = "ellipse",
                      width = 6, height = 6,
                      row.index = 10, col.index = 24,
                      B.values = 0.1, im.res = im.res)

# to store data
data.list <- list()

# run simulations
set.seed(23432)
t1 <- proc.time()
for (m in 1:M) {

  # generate data
  if (x.ms == "continuous") {
    datm <- sim_Y_MVN_X(N = N, dist = y.ms,
                        L = L, B = betas$B)
  } else {
    # from second line on will likely need adjustments
    datm <- sim_Y_Binary_X(N = N, dist = "binomial", B = betas$B, im.res = im.res,
                           lambda = 50, sub.area = TRUE,
                           min.sa = c(0.15, 0.2), max.sa = c(0.25, 0.5),
                           radius.bounds.min.sa = c(0.02, 0.04),
                           radius.bounds.max.sa = c(0.045, 0.06))
  }

  data.list[[m]] <- datm
  cat("Simulation ", m, " has completed. \n")
}
proc.time() - t1

# break up into more maneageable pieces; here 10 independent datasets of 1k each.
D <- 10
# size of each data set; i.e., 1k in this case.
S <- M/D

for (d in 1:D) {
  min <- 1 + (S * (d - 1))
  max <- S * d
  saveRDS(data.list[min:max], file = paste0("/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_", d, ".RDS"))
}






















