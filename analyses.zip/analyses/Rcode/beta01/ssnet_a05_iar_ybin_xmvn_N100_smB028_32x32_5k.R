# Model fit: ssnet w/ alpha = 0.5 & IAR
# Binary outcomes; MVN images
# N <- 100
# betas <- 0.1
# 32 x 32 images
# non-zero parameters: 29 (~2.8%)
# (1st 5k datasets)
# s0 from 0.01 to 0.30 by 0.01

library(tidyverse)
library(sim2Dpredictr)

# image resolution
im.res <- c(32, 32)

# package to fit model
library(BhGLM)
library(rstan)
rstan_options(auto_write = TRUE)
library(ssnet)

models <- "ss_iar"
alpha <- 0.5

# load data -> use array jobs
runID <- as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))

if (runID %in% 1:4) {
  simdata <- readRDS(file = "/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_1.RDS")
  if (runID == 1) {
    simdata <- simdata[1:250]
  } 
  if (runID == 2) {
    simdata <- simdata[251:500]
  }
  if (runID == 3) {
    simdata <- simdata[501:750]
  }
  if (runID == 4) {
    simdata <- simdata[751:1000]
  }
}

if (runID %in% 5:8) {
    simdata <- readRDS(file = "/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_2.RDS")
    if (runID == 5) {
      simdata <- simdata[1:250]
    } 
    if (runID == 6) {
      simdata <- simdata[251:500]
    }
    if (runID == 7) {
      simdata <- simdata[501:750]
    }
    if (runID == 8) {
      simdata <- simdata[751:1000]
    }
}

if (runID %in% 9:12) {
  simdata <- readRDS(file = "/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_3.RDS")
  if (runID == 9) {
    simdata <- simdata[1:250]
  } 
  if (runID == 10) {
    simdata <- simdata[251:500]
  }
  if (runID == 11) {
    simdata <- simdata[501:750]
  }
  if (runID == 12) {
    simdata <- simdata[751:1000]
  }
}

if (runID %in% 13:16) {
  simdata <- readRDS(file = "/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_4.RDS")
  if (runID == 13) {
    simdata <- simdata[1:250]
  } 
  if (runID == 14) {
    simdata <- simdata[251:500]
  }
  if (runID == 15) {
    simdata <- simdata[501:750]
  }
  if (runID == 16) {
    simdata <- simdata[751:1000]
  }
}

if (runID %in% 17:20) {
  simdata <- readRDS(file = "/data/user/jleach/sim_01_2020/simdata/simdata_ybin_xmvn_N100_smB028_32x32_5.RDS")
  if (runID == 17) {
    simdata <- simdata[1:250]
  } 
  if (runID == 18) {
    simdata <- simdata[251:500]
  }
  if (runID == 19) {
    simdata <- simdata[501:750]
  }
  if (runID == 20) {
    simdata <- simdata[751:1000]
  }
}


# Get M from length of list of dataframes
M <- length(simdata)

# IAR info for stan
adjmat <- proximity_builder(im.res = im.res, type = "sparse")
model_info <- mungeCARdata4stan(adjmat$nb.index,
                                table(adjmat$location.index))

# generate parameter vector
betas <- beta_builder(index.type = "ellipse",
                      w = 6, h = 6,
                      row.index = 10, col.index = 24,
                      B.values = 0.1, im.res = im.res)

# to store errors
file.create(paste0("/data/user/jleach/p2-finalsims/errors/errors_ssnet_a05_iar_ybin_xmvn_N100_smB028_32x32_250_",
                   runID, ".txt"))

## pre-specify stan model
sm <- stan_model(file = "/data/user/jleach/sim_01_2020/stan_models/iar_incl_prob_notau.stan")

t1 <- proc.time()
for (m in 1:M) {

  datm <- simdata[[m]]

  tryCatch(
    expr = {
      fits.m <- compare_ssnet(x = as.matrix(datm[, grep("X.*", names(datm), perl = TRUE)]),
                           alpha = alpha,
                           y = datm$Y, models = models, im.res = im.res,
                           family = "binomial", model_fit = "all",
                           variable_selection = TRUE, verbose = FALSE,
                           type_error = "kcv", nfolds = 10, ncv = 1,
                           B = betas$B[-1],
                           iar.data = model_info,
                           # tau.prior = "none",
                           stan_manual = sm,
                           fold.seed = 438774,
                           s0 = seq(0.01, 0.3, 0.01),
                           s1 = 1,
                           output_param_est = TRUE)

      if (m > 1 & exists("fits") == TRUE) {
        fits <- rbind(fits, fits.m$inference)
        ests <- rbind(ests, fits.m$estimates)
      } else {
        fits <- fits.m$inference
        ests <- fits.m$estimates
      }
    },
    error = function(e) {
      message("* Caught an error on iteration ", m)
      print(e)
      write_lines(paste("Iteration #", m , ":", as.character(e)),
                  path = paste0("/data/user/jleach/p2-finalsims/errors/errors_ssnet_a05_iar_ybin_xmvn_N100_smB028_32x32_250_",
                                runID, ".txt"),
                  append = TRUE)
    },
    finally = {
      message(cat(models, " fit for simulated dataset ", m, " has completed."))
    }
  )
}
fit.time <- proc.time() - t1
fit.time

results <- smry_ssnet(fits, output = "mean")

out <- list(fit.time = fit.time,
            estimates = ests,
            inference = fits,
            results = results)

saveRDS(out,
        file = paste0("/data/user/jleach/p2-finalsims/results/results_ssnet-iar_a05_ybin_xmvn_N100_smB028_32x32_250_",
                      runID, ".RDS"))

