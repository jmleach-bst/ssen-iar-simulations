#!/bin/bash
#SBATCH --array=1-10
#SBATCH --share
#SBATCH --partition=medium
#SBATCH --job-name=ssnet_a1_iar_ybin_xmvn_N25_B028_32x32_5k
#SBATCH --error=ssnet_a1_iar_ybin_xmvn_N25_B028_32x32_5k_%a.err
#SBATCH --output=ssnet_a1_iar_ybin_xmvn_N25_B028_32x32_5k_%a.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=jleach@uab.edu
#SBATCH --time=49:59:00
#SBATCH --mem-per-cpu=50GB

module load R/3.6.0-foss-2018a-X11-20180131-bare
srun R CMD BATCH /data/user/jleach/p2-finalsims/rcode/ssnet_a1_iar_ybin_xmvn_N25_B028_32x32_5k.R
