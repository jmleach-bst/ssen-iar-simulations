#!/bin/bash
#SBATCH --share
#SBATCH --partition=short
#SBATCH --job-name=glmnet_a05_ybin_xmvn_N50_B028_32x32
#SBATCH --error=glmnet_a05_ybin_xmvn_N50_B028_32x32.err
#SBATCH --output=glmnet_a05_ybin_xmvn_N50_B028_32x32.out
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mail-type=FAIL
#SBATCH --mail-user=jleach@uab.edu
#SBATCH --time=11:59:00
#SBATCH --mem-per-cpu=50GB

module load R/3.6.0-foss-2018a-X11-20180131-bare
srun R CMD BATCH /data/user/jleach/p2-finalsims/rcode/glmnet_a05_ybin_xmvn_N50_B028_32x32_5k.R
